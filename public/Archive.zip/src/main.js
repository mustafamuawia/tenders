import React, { useState,useEffect } from 'react';

function Main() {
  
    return (<>
<h1 className="page-header">Control Panel</h1>

{/* <div className="row placeholders">
  <div className="col-xs-6 col-sm-6 placeholder">
    <img data-src="holder.js/200x200/auto/sky" className="img-responsive" alt="Generic placeholder thumbnail"/>
    <h4>Partners</h4>
    <span className="text-muted"></span>
  </div>
  <div className="col-xs-6 col-sm-6 placeholder">
    <img data-src="holder.js/200x200/auto/vine" className="img-responsive" alt="Generic placeholder thumbnail"/>
    <h4>Projects</h4>
    <span className="text-muted"></span>
  </div> 
  
</div>*/}
</>
    )
}
export default Main;